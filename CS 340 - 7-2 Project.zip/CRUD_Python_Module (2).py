# Example Python Code to Insert a Document 

from pymongo import MongoClient 
from bson.objectid import ObjectId 

class AnimalShelter(object): 
    """ CRUD operations for Animal collection in MongoDB """ 

    def __init__(self): 
        # Initializing the MongoClient. This helps to access the MongoDB
        # databases and collections. This is hard-wired to use the aac 
        # database, the animals collection, and the aac user. 
        # 
        # You must edit the password below for your environment. 
        # 
        # Connection Variables 
        # 
        USER = 'aacuser' 
        PASS = 'SNHU1234' 
        HOST = 'localhost' 
        PORT = 27017 
        DB = 'aac' 
        COL = 'animals' 
        # 
        # Initialize Connection 
        # 
        self.client = MongoClient('mongodb://%s:%s@%s:%d' % (USER,PASS,HOST,PORT)) 
        self.database = self.client['%s' % (DB)] 
        self.collection = self.database['%s' % (COL)] 

    # Create a method to return the next available record number for use in the create method
    def get_next_record_number(self):
        try:
            last_record = self.database.animals.find().sort('rec_num', -1).limit(1)   # find last record number
            last_record = next(last_record, None)   # get single document from cursor, or returns None
            available_record = (last_record['rec_num'] + 1) if last_record else 1   # increments record number by 1
            return available_record
        except Exception as e:
            print(f"Error retrieving next record number: {e}")
            raise
            
    # Complete this create method to implement the C in CRUD. 
    def create(self, data):
        if data is not None:
            try:
                result = self.database.animals.insert_one(data)  # data should be dictionary
                return result.acknowledged   # confirms insert acknowledged by mongo DB server
            except Exception as e:   # throws an exception otherwise and returns false
                print(f"Error inserting document: {e}")
                return False
        else: 
            raise Exception("Nothing to save, because data parameter is empty") 

    # Create method to implement the R in CRUD.
    def read(self, data):
        if data is not None: 
            document_list = []   # list creation
            for document in self.database.animals.find(data):   # data should be dictionary, traverses collection
                document_list.append(document)   # adds results to list
        else: 
            raise Exception("Nothing to save, because data parameter is empty") 
        return document_list
    
    # Create method to implement the U in CRUD.
    def update(self, filter_data, update_data):
        if filter_data is not None and update_data is not None:
            try:
                result = self.database.animals.update_one(filter_data, {"$set": update_data})   # data for search and update dictionaries to be updated
                return result.modified_count   # returns number documents that have been edited
            except Exception as e:   # throws an exception otherwise and returns false
                print(f"Error updating document: {e}")
                return False
        else:
            raise Exception("Nothing to update, filter or update data is empty")
        
    # Create method to implement the D in CRUD.
    def delete(self, data):
        if data is not None:
            try:
                result = self.database.animals.delete_one(data)   # data should be dictionary, traverses collection and deletes first instance of matching document
                return result.deleted_count   # returns number documents that have been deleted
            except Exception as e:   # throws an exception otherwise and returns false
                print(f"Error deleting document: {e}")
                return False
        else:
            raise Exception("Nothing to delete, filter or update data is empty")
            